//
//  CloudWorkspaceRow.swift
//  ConductorCloud
//
//  Created by Gannon Prudomme on 7/24/26.
//

import ConductorDesign
import Foundation
import LucideIcons
import SwiftUI

public struct CloudWorkspaceRow: View {
    private let item: CloudProjectWorkspace
    private let status: CloudWorkspaceStatusResponse?
    private let action: @MainActor () -> Void

    public init(
        item: CloudProjectWorkspace,
        status: CloudWorkspaceStatusResponse?,
        action: @escaping @MainActor () -> Void
    ) {
        self.item = item
        self.status = status
        self.action = action
    }

    public var body: some View {
        Button(action: action) {
            Label {
                VStack(alignment: .leading, spacing: 2) {
                    HStack(spacing: 5) {
                        Text(item.workspace.name)
                            .lineLimit(1)

                        CloudWorkspaceIcon(size: 16)
                            .accessibilityLabel("Cloud workspace")
                    }

                    HStack(spacing: 5) {
                        Text(item.project.name)

                        if let status {
                            Text("·")
                            Text(status.status.title)
                        }

                        if let lastActivityAt = item.workspace.lastActivityAt {
                            Text("·")
                            Text(lastActivityAt, style: .relative)
                        }
                    }
                    .font(.theme(.small))
                    .foregroundStyle(.theme(.textSecondary))
                    .lineLimit(1)
                }
            } icon: {
                LucideIcon(Lucide.gitBranch, size: 20, relativeTo: .body)
                    .foregroundStyle(.theme(.textSecondary))
            }
            .labelStyle(.conductorStandard)
            .frame(maxWidth: .infinity, alignment: .leading)
            .foregroundStyle(.theme(.textPrimary))
            .font(.theme(.body))
            .contentShape(.rect)
        }
        .buttonStyle(.plain)
    }
}

public extension CloudWorkspaceStatus {
    var title: String {
        switch self {
        case .initializing:
            "Initializing"
        case .ready:
            "Ready"
        case .sleeping:
            "Sleeping"
        case .archived:
            "Archived"
        case .deleted:
            "Deleted"
        case .updating:
            "Updating"
        default:
            rawValue
        }
    }
}
